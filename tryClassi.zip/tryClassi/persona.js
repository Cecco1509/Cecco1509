'use strict'

module.exports = class Persona {
    constructor(eta, nome) {
        this.eta = eta;
        this.nome = nome;
    }
 
    compleanno() {
        this.eta++
    }
}
