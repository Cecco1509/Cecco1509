// try catch
class opError extends Error{
    constructor(...args){
        super(...args)
        this.name = "opError";
    }
}
function calc1(a){
    [op, ...x] = a;
    switch(op){
        case "+":{
            return x.reduce((a,b)=>a+b)
        }
        case "-":{
            return x.reduce((a,b)=>a-b)
        }
        case "/":{
            return x.reduce((a,b)=>a/b)
        }
        case "*":{
            return x.reduce((a,b)=>a*b)
        }
        default :
            throw new opError("operatore non valido");
    }
}

function calcAll(expr) {
    let res;
    try {
        res = expr.map(calc1);
    } catch (error) {
        console.log(error.name)
        res = null;
    }
    return res;
}

console.log(calcAll([["+",3,4,5,66],["g",3,4,5,66]]))