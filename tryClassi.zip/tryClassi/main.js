
const Person = require('./persona.js');

var someone = new Person("35", "Luca");
someone.display();