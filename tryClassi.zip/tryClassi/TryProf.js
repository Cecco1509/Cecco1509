class codaLimitata{
    constructor(size){
        this.max = size;
        this.arr = [];
    }
    enqueue(item){
        if(this.arr.length == this.max)
            this.arr.shift();
        this.arr.push(item);
    }

    dequeue(){
        if(this.arr.length == 0)
            return ;
        return this.arr.shift()
    }

    peek(){
        if(this.arr.length == 0)
            return undefined
        return this.arr[0];
    }

    len(){
        return this.arr.length;
    }
}

class Persona{
    #cognome;
    static #count = 0;

    constructor(nome,eta){
        this.nome = nome;
        this.eta = eta;
        this.#cognome = "no";
        Persona.#count++;
    }

    compleanno(){
        this.eta++;
    }

    get nome() {
        return this._nome;
    }

    set nome(newNome) {
        this._nome = newNome;
    }

    get cognome(){
        return this.#cognome;
    }

    static get count(){
        return this.#count;
    }
}

class Studente extends Persona{
    constructor(nome, eta, indirizzo){
        super(nome,eta);
        this.indirizzo = indirizzo;
    }
    laurea(){
        console.log("Evviva!!!")
    }

    
}

function* generator(a,b){
    var i=a;
    while (i<b) 
        yield i++;
}


class Poesia{
    #testo;
    constructor(testo){
        this.#testo = testo;
    }
    *parole (){
        let i = 0;
        while (true) {
            let f = this.#testo.indexOf(" ",i);
            if (f >= 0) {
                yield this.#testo.slice(i,f);
            }else{
                yield this.#testo.slice(i);
                break;
            }
            i = f +1;
        }
    }
}


class Relation{
    #num;
    #den;
    constructor(num, den=1){
        this.#num = num;
        this.#den = den;
    }

    get num(){
        return this.#num;
    }

    get den(){
        return this.#den;
    }

    simplify(){
        //segno
        if(this.#num * this.den > 0){
            this.#num = Math.abs(this.#num);
            this.#den = Math.abs(this.#den);
        }

        //mcd
        let mcd = this.#mcd();
        while (this.#num != 1 && this.#den != 1 && mcd != -1){
            this.#den /= mcd;
            this.#num /= mcd;
            mcd = this.#mcd();
        }
    }

    #mcd(){
        let min = Math.min(Math.abs(this.#num),Math.abs(this.#den))
        let last = -1;
        for (let i = 2; i <= min; i++) {
            if(this.#num % i == 0 && this.#den % i == 0){
                last = i;
            }
                
        }
        return last;
    }

    print(){
        console.log(`${this.#num} / ${this.#den}`)
        return `${this.#num} / ${this.#den}`;
    }

    plus(){

    }

    takeoff(){

    }
}
/*
let r = new Relation(30,10);
r.print();
r.simplify();
r.print();
*/


class Polinomio{

    constructor(c){
        this.cVector = c;
        this.grado = this.cVector.length - 1; 
    }

    toString(){
        let stmp = "";
        for (let i = this.grado; i > 0; i--) {
            if(this.cVector[i]!=0)
                this.cVector[i-1] >= 0 ? stmp += `${Math.abs(this.cVector[i])}x^${i} + ` : stmp += `${Math.abs(this.cVector[i])}x^${i} - `;
        }
        return stmp + Math.abs(this.cVector[0]);
    }

    eval(x){
        let val = 0;
        for (let i = 0; i < this.cVector.length; i++) {
            val += this.cVector[i]*(x**i);
        }
        return val;
    }

    plus(p1){
        let max = 0;
        let res = [];
        this.grado > p1.grado ? max = this.grado : max = p1.grado;
        for (let i = 0; i <= max; i++) {
            if(this.cVector[i] != undefined || p1.cVector[i] != undefined){
                let v1 = this.cVector[i] || 0;
                let v2 = p1.cVector[i] || 0;
                res.push(v1+v2);
            }
        }
        return new Polinomio(res);
    }
}

let p = new Polinomio([1,-4,3,8,0,9]);
let p1 = new Polinomio([2,-4,4,0]);
console.log("1) "+p.toString());
console.log("2) "+p1.toString());
console.log("plus) "+(p.plus(p1)).toString());