class ArgumentError extends Error{
    constructor(...args){
        super(...args);
        this.name = "ArgumentError";
    }
}
class generator{
    constructor(){;}

    *generaRange(a,b){
        if(isNaN(a) || isNaN(b)) throw new ArgumentError("Uno dei parametri non è un numero");
        if(Math.abs(a) == Infinity || Math.abs(b) == Infinity) throw new ArgumentError("Uno dei parametri é Infinity o -Infinity");
        for (let i = a; i <= b; i++) {
            yield i;
        }
    }
}
/*
let g = new generator();
let range = [];
try {
    range = [...g.generaRange(3,6)];
} catch (e) {
    console.log(e.name,":",e.message);
} finally {
    console.log("res : ",range);
}
*/

class BadOpError extends Error{
    constructor(...args){
        super(...args);
        this.name = "BadOpError";
    }
}

class NumeroModulare{
    constructor(v,m){
        this.v = v;
        this.m = m;
    }

    add(n){
        if(n.m != this.m) throw new BadOpError("il modulo è diverso");
        return new NumeroModulare(this.v+n.v,this.m)
    }

    equal(n){
        if(this.v % this.m == n.v % n.m) return true;
        return false;
    }

    toString(){
        return `[${this.v%this.m}%${this.m}]`;
    }
}
/*
let n1 = new NumeroModulare(17,5);
let n2 = new NumeroModulare(16,5);
*/


class Studente{
    #carriera = [];
    constructor(matricola, nome, corsoLaurea, anno, corso, nazionalita){
        if(isNaN(matricola) || !isFinite(matricola)) throw new Error();
        if(typeof(nome) != "string") throw new Error();
        this.matricola = matricola;
        this.nome = nome;
        this.corsoLaurea = "" || corsoLaurea;
        this.anno = 0 || anno;
        this.corso = "" || corso;
        this.nazionalita = "" || nazionalita; 
    }

    passato(esame){
        if(esame.materia == undefined || esame.cfu == undefined ||esame.voto == undefined||esame.lode == undefined)
            throw new Error();
        this.#carriera.push(esame);
    }

    media(){

    }

}

let s = new Studente(3245,"franco");
s.passato({materia: "FDI", cfu: 12, voto: 30, lode: false});
console.log(s);